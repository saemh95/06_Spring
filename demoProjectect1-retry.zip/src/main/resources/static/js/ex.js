document.querySelector("#btn").addEventListener("click", () => {

    alert("clicked");
});