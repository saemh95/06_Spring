package edu.kh.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoProjectect1RetryApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoProjectect1RetryApplication.class, args);
	}

}
